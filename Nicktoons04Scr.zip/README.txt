Nicktoons '04 - Pixels Screensaver
Version 1.0
-------------------------------------
Made by chillycontro of https://contro-world.neocities.org/
This screensaver uses things from the 2004-2005 Nicktoons UK website, mainly Black and Blue's graphics.
-------------------------------------
This screensaver was made with Clickteam Fusion 2.5.
The Pixels are not mine!
-------------------------------------
That's all I have to say, and I hope you enjoy this screensaver.