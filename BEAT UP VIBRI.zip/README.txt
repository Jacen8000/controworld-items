BEAT UP VIBRI v1.0.0
Beat up Vibri in increasingly ridiculous ways


STRAT GUIDE:
LEVEL 1: Click to shoot
LEVEL 2: Arrow keys to drive, left click to shoot
LEVEL 3: Arrow keys to move
LEVEL 4: Arrow keys to walk, shift to jump
LEVEL 5: Arrow keys to move, left & right click to play
LEVEL 6: Arrow keys to move
LEVEL 7: Left click to shoot
LEVEL 8: Arrow keys to move, shift to fire
LEVEL 9: ????
LEVEL 10: ????